package com.huertos.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HuertosApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HuertosApiApplication.class, args);
	}

}
